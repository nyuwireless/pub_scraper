from flask import Flask, request, jsonify
import psycopg2
import os
import json
import logging

app = Flask(__name__)

DATABASE_URL = os.environ['DATABASE_URL']

def get_db_connection():
    conn = psycopg2.connect(DATABASE_URL, sslmode='require')
    return conn

@app.route('/')
def index():
    return "Welcome to the Publication Form Submission App!"

@app.route('/submit', methods=['POST'])
def submit():
    try:
        data = request.form.to_dict(flat=False)  # Use flat=False to get lists of values for each key
        app.logger.info(f"Form data received: {data}")
        
        form_id = data.pop('form_id', [None])[0]  # Extract form ID
        if not form_id:
            raise KeyError('form_id')
        
        app.logger.info(f"Form ID: {form_id}")
        
        for key in data:
            if len(data[key]) == 1:
                data[key] = data[key][0]
        
        data['form_id'] = form_id  # Include form ID in the data
        app.logger.info(f"Processed data: {data}")
        
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("INSERT INTO submissions (data) VALUES (%s)", (json.dumps(data),))
        conn.commit()
        cur.close()
        conn.close()
        
        return "Thank you for your submission!"
    except Exception as e:
        app.logger.error(f"Error processing form: {e}")
        return "Internal Server Error", 500

if __name__ == '__main__':
    app.run(debug=True)
